const token = localStorage.getItem('token');
console.log(token);
// find the login and the create account buttons
// hide them when there is token
// unhide them when there is no token
// unhide them when token expire

// // for the login button
// const loginButton = document.getElementById("login-button");

// //for create account button

// const createAccountButton = document.getElementById("create-account-button");

// if (token) {
//     console.log(token);
//     loginButton.style.display = 'none';
//     createAccountButton.style.display = "none";
// }
