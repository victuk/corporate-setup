//Template to make naming easy ;)
//const  = document.getElementById("");

const userProfileList = document.getElementById("user-profile-list");

const uploadProfilePicture = document.getElementById("upload-picture-button");

const searchInput = document.getElementById("search-input");

const searchButton = document.getElementById("search-button");

const profilePicture = document.getElementById("profile-picture");

