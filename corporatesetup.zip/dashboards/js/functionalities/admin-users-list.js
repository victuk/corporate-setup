//Template to make naming easy ;)
//const  = document.getElementById("");

const userList = document.getElementById("user-list");

const searchInput = document.getElementById("search-input");

const searchButton = document.getElementById("search-button");


