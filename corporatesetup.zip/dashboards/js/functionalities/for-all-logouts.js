const logOutButton = document.getElementById('log-out-button');
